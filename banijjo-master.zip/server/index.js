const express = require("express");
const bodyParser = require("body-parser");
const mysql = require("mysql");
var cors = require("cors");
const app = express();
const util = require("util");
var cookieParser = require("cookie-parser");
const session = require("express-session");
const fetch = require("node-fetch");
const request = require("request");

app.use(cors());
app.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*"); // update to match the domain you will make the request from
  res.header(
    "Access-Control-Allow-Headers",
    "Origin, X-Requested-With, Content-Type, Accept"
  );
  next();
});
app.use(cookieParser());
app.use(
  session({ secret: "banijjo", saveUninitialized: false, resave: false })
);

app.use(bodyParser.urlencoded({ extended: false }));

const dbConnection = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "ecommerce"
});

const query = util.promisify(dbConnection.query).bind(dbConnection);

dbConnection.connect(err => {
  if (err) {
    throw err;
  }
  console.log("Connected to database");
});

// app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(
  bodyParser.urlencoded({
    extended: true
  })
);

app.get("/api/categories", (req, res) => {
  dbConnection.query("SELECT * FROM category", function(
    error,
    results,
    fields
  ) {
    if (error) throw error;
    return res.send({ error: false, data: results, message: "users list." });
  });
});

app.get("/api/feature_name", async (req, res) => {
  const feature_name = await query("SELECT * FROM feature_name");

  return res.send(feature_name);
});

app.get("/api/all_product_list", async function(req, res, next) {
  const resultArray = {};
  const feature_name = await query("SELECT * FROM feature_name");
  const categoryName = await query("SELECT * FROM category");
  const bannerImagesCustom = await query(
    "SELECT * FROM banner WHERE softDel = 0"
  );

  for (const i in feature_name) {
    if (feature_name[i].code === 2) {
      resultArray.HotDeals = await query(
        "SELECT feature_products FROM feature_products where feature_id=" +
          feature_name[i].id
      );
      resultArray.HotDealsTitle = feature_name[i].name;
    } else if (feature_name[i].code === 3) {
      resultArray.TopSelections = await query(
        "SELECT feature_products FROM feature_products where feature_id=" +
          feature_name[i].id
      );
      resultArray.TopSelectionsTitle = feature_name[i].name;
    } else if (feature_name[i].code === 4) {
      resultArray.NewForYou = await query(
        "SELECT feature_products FROM feature_products where feature_id=" +
          feature_name[i].id
      );
      resultArray.NewForYouTitle = feature_name[i].name;
    } else if (feature_name[i].code === 0) {
      resultArray.BannerTop = await query(
        "SELECT feature_products FROM feature_products where feature_id=" +
          feature_name[i].id
      );
      resultArray.BannerTopTitle = feature_name[i].name;
    } else if (feature_name[i].code === 6) {
      resultArray.StoreWIllLove = await query(
        "SELECT feature_products FROM feature_products where feature_id=" +
          feature_name[i].id
      );
      resultArray.StoreWIllLoveTitle = feature_name[i].name;
    } else if (feature_name[i].code === 7) {
      resultArray.More = await query(
        "SELECT feature_products FROM feature_products where feature_id=" +
          feature_name[i].id
      );
      resultArray.MoreTitle = feature_name[i].name;
    } else if (feature_name[i].code === 1) {
      resultArray.BannerImages = await query(
        "SELECT feature_products FROM feature_products where feature_id=" +
          feature_name[i].id
      );
      resultArray.BannerImagesTitle = feature_name[i].name;
    } else if (feature_name[i].code === 5) {
      resultArray.FeaturedBrands = await query(
        "SELECT feature_products FROM feature_products where feature_id=" +
          feature_name[i].id
      );
      resultArray.FeaturedBrandsTitle = feature_name[i].name;
    }
  }

  resultArray.categories = categoryName;
  resultArray.bannerImagesCustom = bannerImagesCustom;
  return res.send({
    error: false,
    data: resultArray,
    message: "all Product list."
  });
});

app.post("/api/productDetails", async (req, res) => {
  const resultArray = {};
  const specificationActualArray = [];
  const productDetails = await query(
    "SELECT * FROM products where id=" + req.body.productId + " limit 1"
  );
  const specificationArray = JSON.parse(
    productDetails[0].product_specification_name
  );
  for (const i in specificationArray) {
    let tempObject = {};
    tempObject.specificationNameValue =
      specificationArray[i].specificationNameValue;
    const productListSmVendorOtherCategory = await query(
      "SELECT specification_name FROM product_specification_names where id=" +
        specificationArray[i].specificationNameId +
        ""
    );
    tempObject.specificationName =
      productListSmVendorOtherCategory[0].specification_name;
    specificationActualArray.push(tempObject);
  }
  const productListSmVendorOtherCategory = await query(
    "SELECT product_name,product_sku,home_image,productPrice,id FROM products where vendor_id=" +
      productDetails[0].vendor_id +
      " and category_id not in(" +
      productDetails[0].category_id +
      ") and id not in(" +
      productDetails[0].id +
      ") limit 5"
  );
  const productListSmCategoryOthersVendor = await query(
    "SELECT product_name,product_sku,home_image,productPrice,id FROM products where category_id=" +
      productDetails[0].category_id +
      " and vendor_id not in(" +
      productDetails[0].vendor_id +
      ") and id not in(" +
      productDetails[0].id +
      ") limit 5"
  );
  resultArray.productDetails = productDetails;
  resultArray.productSpecifications = specificationActualArray;
  resultArray.producSmVendor = productListSmVendorOtherCategory;
  resultArray.productSmCategory = productListSmCategoryOthersVendor;
  return res.send({
    error: false,
    data: resultArray,
    message: "all Product Deatils list."
  });
});
var lastChildsAll = [];

app.get("/api/sidebar_category", async (req, res) => {
  try {
    const categories = await query(
      `Select * FROM category_order WHERE status=1`
    );

    return res.send({
      error: false,
      data: categories,
      message: "all category list."
    });
  } catch (e) {
    console.error(e);
  }
});

app.get("/api/child_categories", async (req, res) => {
  try {
    let c_id = req.query.id;

    let category_ids = [c_id];
    let categoryArray = [];

    let categoryObj = {};
    var lastChildsObjects = [];

    const subCategoriesList = await query(
      `SELECT * FROM category where parent_category_id=${c_id}`
    );

    console.log("subCategoriesList : ", subCategoriesList);

    for (const j in subCategoriesList) {
      let lastObj = {};
      category_ids = [...category_ids, subCategoriesList[j].id];

      // var childArray = findoutChildsOfSub(subCategoriesList[j].id,allCategories);
      var childArray = await query(
        "SELECT * FROM category where parent_category_id=" +
          subCategoriesList[j].id +
          ""
      );

      // console.log("childArray : ", childArray);

      for (const k in childArray)
        category_ids = [...category_ids, childArray[k].id];

      lastObj.category = subCategoriesList[j];
      lastObj.lastChilds = childArray;
      lastChildsObjects.push(lastObj);
      // console.log("lastChildsObjects : ", lastChildsObjects);
      console.log("=========================");
    }

    let vendor_ids = [];

    for (const c_id in category_ids) {
      const v_ids = await query(
        `select distinct vendor_id from products where category_id = ${category_ids[c_id]}`
      );

      // console.log("v_ids : ", v_ids);

      vendor_ids = [...vendor_ids, ...v_ids];
    }

    const distinct_vendor_ids = [...new Set(vendor_ids.map(x => x.vendor_id))];
    // console.log("distinct_vendor_ids: ", distinct_vendor_ids);

    let vendor_images = [];

    for (const id of distinct_vendor_ids) {
      const v_image = await query(
        `select vendor_id, logo from vendor_details where vendor_id=${id}`
      );

      // console.log("v_image : ", v_image);

      vendor_images = [...vendor_images, ...v_image];
    }

    categoryObj.subcategories = lastChildsObjects;
    categoryObj.vendorImages = vendor_images;
    categoryArray.push(categoryObj);

    // console.log("categoryArray : ", categoryArray);

    return res.send({
      error: false,
      data: categoryArray,
      message: "all category list."
    });
  } catch (e) {
    console.error(e);
    res.status(500).send("Server Error");
  }
});

app.get("/api/all_category_list", async (req, res) => {
  var categories = await query(
    "SELECT category.id,category.category_name,category_order.status from category_order LEFT JOIN category ON category_order.category_id = category.id"
  );

  var categoryArray = [];
  let vendor_images = [];
  if (categories.length > 0) {
    lastChildsAll.length = 0;
    for (const i in categories) {
      let category_ids = [];
      category_ids = [...category_ids, categories[i].id];
      let categoryObj = {};
      var lastChildsObjects = [];
      const subCategoriesList = await query(
        "SELECT * FROM category where parent_category_id=" +
          categories[i].id +
          ""
      );

      for (const j in subCategoriesList) {
        let lastObj = {};
        category_ids = [...category_ids, subCategoriesList[j].id];

        // var childArray = findoutChildsOfSub(subCategoriesList[j].id,allCategories);
        var childArray = await query(
          "SELECT * FROM category where parent_category_id=" +
            subCategoriesList[j].id +
            ""
        );

        for (const k in childArray)
          category_ids = [...category_ids, childArray[k].id];

        lastObj.category = subCategoriesList[j];
        lastObj.lastChilds = childArray;
        lastChildsObjects.push(lastObj);
      }
      let vendor_ids = [];

      for (const c_id in category_ids) {
        const v_ids = await query(
          `select distinct vendor_id from products where category_id = ${category_ids[c_id]}`
        );
        vendor_ids = [...vendor_ids, ...v_ids];
      }

      const distinct_vendor_ids = [
        ...new Set(vendor_ids.map(x => x.vendor_id))
      ];

      let vendor_images = [];

      for (const id of distinct_vendor_ids) {
        const v_image = await query(
          `select vendor_id, logo from vendor_details where vendor_id=${id}`
        );
        vendor_images = [...vendor_images, ...v_image];
      }

      categoryObj.category = categories[i];
      categoryObj.subcategories = lastChildsObjects;
      categoryObj.vendorImages = vendor_images;
      categoryArray.push(categoryObj);
    }
  }

  console.log("categoryArray : ", categoryArray);

  return res.send({
    error: false,
    data: categoryArray,
    message: "all category list."
  });
});

app.get("/api/all_category_list_more", async (req, res) => {
  var categories = await query(
    "SELECT * FROM category where parent_category_id=0"
  );

  var categoryArray = [];
  if (categories.length > 0) {
    lastChildsAll.length = 0;
    for (const i in categories) {
      let categoryObj = {};
      var lastChildsObjects = [];
      const subCategoriesList = await query(
        "SELECT * FROM category where parent_category_id=" +
          categories[i].id +
          ""
      );
      for (const j in subCategoriesList) {
        let lastObj = {};

        // var childArray = findoutChildsOfSub(subCategoriesList[j].id,allCategories);
        var childArray = await query(
          "SELECT * FROM category where parent_category_id=" +
            subCategoriesList[j].id +
            ""
        );
        lastObj.category = subCategoriesList[j];
        lastObj.lastChilds = childArray;
        lastChildsObjects.push(lastObj);
      }
      categoryObj.category = categories[i];
      categoryObj.subcategories = lastChildsObjects;
      categoryArray.push(categoryObj);
    }
  }

  return res.send({
    error: false,
    data: categoryArray,
    message: "all category list."
  });
});

/*var subNodes = [];
function childCategories() {
  subCategories.forEach(subitem => {
    allCategories.forEach(allitem => {
      if (allitem.parent_category_id == subitem.id) {
        subNodes.push(allitem);
      }
    });
  });
}

var childCategoryTree = [];
function childCategoriesTrees(categoryLists, childCategoryItem) {
  categoryLists.forEach(item => {
    if (item.parent_category_id == childCategoryItem.id) {
      childCategoryTree.push(item);
      childCategoriesTrees(categoryLists, item.id);
    }
  });
  return childCategoryTree;
}

var childCategoryIds = [];
function childCategories(categoryLists, parentId) {
  categoryLists.forEach(item => {
    if (item.parent_category_id == parentId) {
      childCategoryIds.push(item.id);
      childCategories(categoryLists, item.id);
    }
  });
  return childCategoryIds;
}*/

// new api
app.post("/api/checkInventory", async (req, res) => {
  try {
    const cartData = req.body.cartProducts;
    for (const i in cartData) {
      const purchaseDetialsQuantity = await query(
        "SELECT sum(inv_purchase_details.quantity) as quantity FROM inv_purchase_details WHERE productId = '" +
          cartData[i].id +
          "'"
      );
      const purchaseReturnQuantity = await query(
        "SELECT sum(inv_purchase_return_details.quantity) as quantity FROM inv_purchase_return_details WHERE productId = '" +
          cartData[i].id +
          "'"
      );
      const salesDetailsQuantity = await query(
        "SELECT sum(sales_details.sales_product_quantity) as quantity FROM sales_details WHERE product_id = '" +
          cartData[i].id +
          "'"
      );
      const salesReturnQuantity = await query(
        "SELECT sum(sales_return_details.salesReturnQuantity) as quantity FROM sales_return_details WHERE productId = '" +
          cartData[i].id +
          "'"
      );
      const itemInventory =
        purchaseDetialsQuantity[0].quantity -
        purchaseReturnQuantity[0].quantity -
        salesDetailsQuantity[0].quantity +
        salesReturnQuantity[0].quantity;

      if (itemInventory > 0) {
        if (itemInventory < cartData[i].quantity) {
          return res.status(200).send({
            error: false,
            data: false,
            message: "Item not in Inventory!"
          });
        }
      } else {
        return res.status(200).send({
          error: false,
          data: false,
          message: "Item not in Inventory!"
        });
      }
    }
    return res.status(200).send({ error: false, data: true, message: "Ok!" });
  } catch (error) {
    return res
      .status(404)
      .send({ error: true, data: false, message: error.message });
  }
});

// new api
app.get("/api/getVendorImages", async (req, res) => {
  const vendorImages = await query(
    "SELECT vendor_id,logo from vendor_details WHERE softDel=0 AND status=1"
  );
  return res.send({ error: false, data: vendorImages, message: "Ok!" });
});

// Get request to fetch top navbar category
app.get("/api/getTopNavbarCategory", async (req, res) => {
  const categories = await query(
    "SELECT * from category_top_navbar WHERE status=1"
  );
  return res.send({ error: false, data: categories, message: "Ok!" });
});

// edited by sojib vai
app.post("/api/payOrder", async (req, res) => {
  try {
    const tempSells = await query(
      "select temp_sell.customer_id,temp_sell.item_ids,temp_sell.quantity,products.productPrice from temp_sell left join products on temp_sell.item_ids=products.id where customer_id='" +
        req.body.customerId +
        "'"
    );
    var totalQuantity = 0;
    var totalPrice = 0;
    var discountAmount = req.body.discountAmount;
    const discountDetail = req.body.discountDetail;
    var promoCodeAmount = req.body.promoCodeAmount;
    const promoCodeDetail = req.body.promoCodeDetail;

    for (const i in tempSells) {
      totalQuantity = totalQuantity + tempSells[i].quantity;
      totalPrice =
        totalPrice + tempSells[i].productPrice * tempSells[i].quantity;
    }

    var finalPrice = totalPrice - discountAmount - promoCodeAmount;
    var date = new Date();
    var year = date.getFullYear();
    var todayDate =
      date.getFullYear() + "-" + (date.getMonth() + 1) + "-" + date.getDate();

    String.prototype.lpad = function(padString, length) {
      var str = this;
      while (str.length < length) str = padString + str;
      return str;
    };

    const saleRecord = await query(
      "SELECT sales_bill_no FROM sales where createdDate BETWEEN CONCAT(YEAR(CURDATE()),'-01-01') AND CONCAT(YEAR(CURDATE())+1,'-12-31') order by id desc LIMIT 1"
    );
    if (saleRecord.length > 0) {
      var saleRecordBillNo = saleRecord[0].sales_bill_no;
      var splitBillNo = saleRecordBillNo.split("-");
      var billPaddingInt = parseInt(splitBillNo[2]) + 1;
      var newBillPadding = billPaddingInt.toString().lpad("0", 7);
      var newBillNo = "BNJ-" + year + "-" + newBillPadding;
    } else {
      var newBillPadding = "1".lpad("0", 7);
      var newBillNo = "BNJ-" + year + "-" + newBillPadding;
    }

    const insertSell = await query(
      "insert into sales(sales_bill_no,sales_type,customer_id,sales_date,total_sales_quantity,total_sales_amount,discount_amount,promo_code,netAmount) VALUES('" +
        newBillNo +
        "','cash','" +
        req.body.customerId +
        "','" +
        todayDate +
        "','" +
        totalQuantity +
        "','" +
        totalPrice +
        "','" +
        discountAmount +
        "','" +
        JSON.stringify(promoCodeDetail) +
        "','" +
        finalPrice +
        "')"
    );
    const salesId = insertSell.insertId;
    const insertPayment = await query(
      "insert into product_payment(customer_id,order_id,payment_amount,payment_method) VALUES('" +
        req.body.customerId +
        "','" +
        salesId +
        "','" +
        finalPrice +
        "','cash')"
    );

    for (const i in tempSells) {
      let totalAmount = tempSells[i].quantity * tempSells[i].productPrice;

      var discountAmount = 0;
      for (j in discountDetail) {
        if (tempSells[i].item_ids == discountDetail[j].productId) {
          discountAmount =
            discountAmount + discountDetail[j].amount * tempSells[i].quantity;
        }
      }

      var customerPayableAmount = totalAmount - discountAmount;

      const purchaseDetialsQuantity = await query(
        "SELECT sum(inv_purchase_details.quantity) as quantity FROM inv_purchase_details WHERE productId = '" +
          tempSells[i].item_ids +
          "'"
      );
      const purchaseReturnQuantity = await query(
        "SELECT sum(inv_purchase_return_details.quantity) as quantity FROM inv_purchase_return_details WHERE productId = '" +
          tempSells[i].item_ids +
          "'"
      );
      const salesDetailsQuantity = await query(
        "SELECT sum(sales_details.sales_product_quantity) as quantity FROM sales_details WHERE product_id = '" +
          tempSells[i].item_ids +
          "'"
      );

      const salesReturnQuantity = await query(
        "SELECT sum(sales_return_details.salesReturnQuantity) as quantity FROM sales_return_details WHERE productId = '" +
          tempSells[i].item_ids +
          "'"
      );
      const itemInventory =
        purchaseDetialsQuantity[0].quantity -
        purchaseReturnQuantity[0].quantity -
        salesDetailsQuantity[0].quantity +
        salesReturnQuantity[0].quantity;

      if (itemInventory > 0) {
        if (itemInventory > tempSells[i].quantity) {
          await query(
            "insert into sales_details(customer_id,sales_bill_no,product_id,sales_product_quantity,unitPrice,total_amount,customer_payable_amount,discounts_amount) VALUES('" +
              req.body.customerId +
              "','" +
              newBillNo +
              "','" +
              tempSells[i].item_ids +
              "','" +
              tempSells[i].quantity +
              "','" +
              tempSells[i].productPrice +
              "','" +
              totalAmount +
              "','" +
              customerPayableAmount +
              "','" +
              discountAmount +
              "')"
          );
          await query(
            "delete from temp_sell where customer_id='" +
              req.body.customerId +
              "' and item_ids='" +
              tempSells[i].item_ids +
              "'"
          );
        } else {
          throw Error("Item Not in Inventory");
        }
      } else {
        throw Error("Item Not in Inventory");
      }
    }

    return res.status(200).send({
      error: false,
      data: true,
      message: "Nice! Your Order Has been placed Successfully"
    });
  } catch (error) {
    return res
      .status(404)
      .send({ error: true, data: false, message: error.message });
  }
});

// new api
app.post("/api/getDiscounts", async (req, res) => {
  const discounts = await query(
    "SELECT * FROM discount WHERE effective_from <= NOW() AND effective_to >= NOW() AND softDel=0 AND status='active'"
  );
  const cartProducts = req.body.cartProducts;

  const cartIds = [];
  const cartProductQty = [];
  if (req.body.customerId) {
    for (let i in cartProducts) {
      cartIds.push(parseInt(cartProducts[i].id));
      cartProductQty.push({
        productId: cartProducts[i].id,
        quantity: cartProducts[i].quantity
      });
    }
  } else {
    for (let i in cartProducts) {
      cartIds.push(parseInt(cartProducts[i].productId));
      cartProductQty.push({
        productId: cartProducts[i].productId,
        quantity: cartProducts[i].quantity
      });
    }
  }

  var discountAmount = 0;
  const discountDetail = [];
  for (let i in discounts) {
    const parsedArr = JSON.parse(discounts[i].product_id);

    for (let j in parsedArr) {
      var specific = parseInt(parsedArr[j].id);
      if (cartIds.includes(specific) === true) {
        for (k in cartProductQty) {
          if (cartProductQty[k].productId == specific) {
            discountAmount =
              discountAmount +
              parseInt(parsedArr[j].discount) * cartProductQty[k].quantity;
          }
        }
        discountDetail.push({
          id: discounts[i].id,
          productId: specific,
          amount: parseInt(parsedArr[j].discount)
        });
      }
    }
  }

  return res.send({
    error: false,
    data: discountAmount,
    dataDetail: discountDetail,
    message: "Yes"
  });
});

// new api
app.post("/api/getPromoCodeAmount", async (req, res) => {
  var promoCodeInput = req.body.promoCodeInput;
  var totalAmount = req.body.totalAmount;
  var customerId = req.body.customerId;

  const promo = await query(
    "SELECT * FROM promocode WHERE promo_code='" +
      promoCodeInput +
      "' AND effective_from <= NOW() AND effective_to >= NOW() AND softDel=0 AND status=1"
  );
  const customerSalesData = await query(
    "select promo_code from sales where customer_id='" + customerId + "'"
  );

  var consumedPromoAmount = 0;
  var usedTimes = 0;
  if (customerSalesData.length > 0) {
    for (let i in customerSalesData) {
      const promoCodeArr = JSON.parse(customerSalesData[i].promo_code);
      for (let j in promoCodeArr) {
        if (promoCodeInput == promoCodeArr[j].code) {
          consumedPromoAmount =
            consumedPromoAmount + parseInt(promoCodeArr[j].amount);
          usedTimes++;
        }
      }
    }
  }

  const promoDetail = [];
  var promoCodeAmount = 0;
  for (let i in promo) {
    var invoice_amount = promo[i].invoice_amount;
    var promo_amount = promo[i].promo_amount;
    var promo_percantage = promo[i].promo_percantage;
    var isMultiple = promo[i].isMultiple;
    var valueAfterPercentageCalculation =
      (promo_percantage / 100) * totalAmount;

    if (valueAfterPercentageCalculation > promo_amount) {
      var applicableAmount = promo_amount;
    } else {
      var applicableAmount = valueAfterPercentageCalculation;
    }

    if (consumedPromoAmount < invoice_amount) {
      if (consumedPromoAmount > 0) {
        if (isMultiple == "yes") {
          if (promo[i].times > usedTimes) {
            promoCodeAmount = promoCodeAmount + applicableAmount;
          } else {
            promoCodeAmount = promoCodeAmount;
          }
        } else {
          promoCodeAmount = promoCodeAmount;
        }
      } else {
        promoCodeAmount = promoCodeAmount + applicableAmount;
      }
    }
  }
  promoDetail.push({ code: promoCodeInput, amount: promoCodeAmount });
  return res.send({
    error: false,
    data: promoCodeAmount,
    dataDetail: promoDetail,
    message: "Yes"
  });
});

// new api
app.post("/api/paySsl", async (req, res) => {
  fetch("http://127.0.0.1:8000/api/ssl", {
    method: "POST",
    crossDomain: true,
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      customerId: req.body.customerId,
      discountAmount: req.body.discountAmount,
      discountDetail: req.body.discountDetail,
      promoCodeAmount: req.body.promoCodeAmount,
      promoCodeDetail: req.body.promoCodeDetail
    })
  })
    .then(res => {
      return res.json();
    })
    .then(data => {
      // console.log(data)
      return res.send({ error: false, data: data, message: "Api Successfull" });
    })
    .catch(err => {
      console.log(err);
    });
});

// revised api
app.post("/api/loginCustomerInitial", async (req, res) => {
  const loginCustomer = await query(
    "select * from customer where email='" +
      req.body.email +
      "' and password='" +
      req.body.password +
      "'"
  );
  if (loginCustomer.length > 0) {
    return res.send({
      error: false,
      data: loginCustomer[0].id,
      message: "Login Successfull"
    });
  } else {
    return res.send({ error: false, data: null, message: "Login Failed" });
  }
});

// revised api
// /api/saveCustomerInitial
app.post("/api/saveCustomerInitial", async (req, res) => {
  const insertCustomer = await query(
    "INSERT INTO customer (email, password) VALUES ('" +
      req.body.email +
      "', '" +
      req.body.password +
      "')"
  );
  if (insertCustomer) {
    const cartData = req.body.cartData;
    if (cartData.length > 0) {
      for (const i in cartData) {
        await query(
          "INSERT INTO temp_sell (customer_id, item_ids,quantity) VALUES ('" +
            insertCustomer.insertId +
            "', '" +
            cartData[i].productId +
            "','" +
            cartData[i].quantity +
            "')"
        );
      }
    }
    return res.send({
      error: false,
      data: insertCustomer.insertId,
      message: "success"
    });
  }
  return res.json({ message: "error" });
});

app.post("/api/add_cart_direct", async (req, res) => {
  const checkIfExist = await query(
    "select * from temp_sell where item_ids='" +
      req.body.productId +
      "' and customer_id='" +
      req.body.customerId +
      "'"
  );
  if (checkIfExist.length > 0) {
    const updateProductTemp = await query(
      "UPDATE temp_sell SET quantity= quantity+1 WHERE customer_id = '" +
        req.body.customerId +
        "' and item_ids='" +
        req.body.productId +
        "'"
    );
  } else {
    const insertProductsTemp = await query(
      "INSERT INTO temp_sell (customer_id, item_ids,quantity) VALUES ('" +
        req.body.customerId +
        "', '" +
        req.body.productId +
        "','" +
        req.body.quantity +
        "')"
    );
  }
  return res.send({ error: false, data: true, message: "success" });
});

// new api
app.post("/api/add_cart_direct_from_wish", async (req, res) => {
  const checkIfExist = await query(
    "select * from temp_sell where item_ids='" +
      req.body.productId +
      "' and customer_id='" +
      req.body.customerId +
      "'"
  );
  if (checkIfExist.length > 0) {
    const updateProductTemp = await query(
      "UPDATE temp_sell SET quantity= quantity+'" +
        req.body.quantity +
        "' WHERE customer_id = '" +
        req.body.customerId +
        "' and item_ids='" +
        req.body.productId +
        "'"
    );
  } else {
    const insertProductsTemp = await query(
      "INSERT INTO temp_sell (customer_id, item_ids,quantity) VALUES ('" +
        req.body.customerId +
        "', '" +
        req.body.productId +
        "','" +
        req.body.quantity +
        "')"
    );
  }
  return res.send({ error: false, data: true, message: "success" });
});

app.post("/api/add_wish_direct", async (req, res) => {
  const checkIfExist = await query(
    "select * from wish_list where item_ids='" +
      req.body.productId +
      "' and customer_id='" +
      req.body.customerId +
      "'"
  );
  if (checkIfExist.length > 0) {
    await query(
      "UPDATE wish_list SET quantity= quantity+1 WHERE customer_id = '" +
        req.body.customerId +
        "' and item_ids='" +
        req.body.productId +
        "'"
    );
  } else {
    await query(
      "INSERT INTO wish_list (customer_id, item_ids, quantity) VALUES ('" +
        req.body.customerId +
        "', '" +
        req.body.productId +
        "','" +
        req.body.quantity +
        "')"
    );
  }
  return res.send({ error: false, data: true, message: "success" });
});

app.post("/api/saveCustomerAddress", async (req, res) => {
  let updateCustomerShipping = await query(
    "UPDATE customer SET name='" +
      req.body.name +
      "',phone_number='" +
      req.body.phone_number +
      "',address='" +
      req.body.address +
      "',city='" +
      req.body.city +
      "',district='" +
      req.body.district +
      "' WHERE id = '" +
      req.body.customerId +
      "'"
  );
  // console.log("UPDATE customer SET name='" + req.body.name + "',phone_number='" + req.body.phone_number + "',address='" + req.body.address + "',city='" + req.body.city + "',district='" + req.body.district + "' WHERE id = '" + req.body.customerId + "'");
  if (updateCustomerShipping) {
    return res.send({ error: false, data: true, message: "success" });
  }
});

app.post("/api/getCustomerCartProducts", async (req, res) => {
  let cartProducts = "";
  if (req.body.customerId === 0) {
    const uniqueProductIds = JSON.parse(req.body.uniqueProductIds);
    cartProducts = await query(
      "SELECT id, product_name, product_specification_details_description, productPrice, home_image FROM products WHERE id IN " +
        "(" +
        uniqueProductIds +
        ")" +
        ""
    );
  } else {
    cartProducts = await query(
      "SELECT products.id,products.product_name,products.productPrice,products.product_specification_details_description,products.productPrice*temp_sell.quantity AS totalPrice, products.home_image,temp_sell.item_ids,temp_sell.quantity FROM temp_sell LEFT JOIN products ON temp_sell.item_ids = products.id WHERE temp_sell.customer_id='" +
        req.body.customerId +
        "'"
    );
  }
  return res.send({
    error: false,
    data: cartProducts,
    message: "customer cart product list."
  });
});

// new api
app.post("/api/getCustomerWishProducts", async (req, res) => {
  let cartProducts = "";
  if (req.body.customerId === 0) {
    const uniqueProductIds = JSON.parse(req.body.uniqueProductIds);
    cartProducts = await query(
      "SELECT id, product_name, product_specification_details_description, productPrice, home_image FROM products WHERE id IN " +
        "(" +
        uniqueProductIds +
        ")" +
        ""
    );
  } else {
    cartProducts = await query(
      "SELECT products.id,products.product_name,products.productPrice,products.product_specification_details_description, products.productPrice*wish_list.quantity AS totalPrice, products.home_image, wish_list.item_ids, wish_list.quantity FROM wish_list LEFT JOIN products ON wish_list.item_ids = products.id WHERE wish_list.customer_id='" +
        req.body.customerId +
        "'"
    );
  }
  return res.send({
    error: false,
    data: cartProducts,
    message: "customer cart product list."
  });
});

// new api
app.post("/api/updateCustomerCartProducts", async (req, res) => {
  if (req.body.type == 0) {
    await query(
      "UPDATE temp_sell SET quantity=quantity-1 WHERE quantity>0 AND customer_id='" +
        req.body.customerId +
        "' AND item_ids='" +
        req.body.itemId +
        "'"
    );
  } else {
    await query(
      "UPDATE temp_sell SET quantity=quantity+1 WHERE customer_id='" +
        req.body.customerId +
        "' AND item_ids='" +
        req.body.itemId +
        "'"
    );
  }
  return res.send({ error: false, message: "Customer cart product updated." });
});

// new api
app.post("/api/updateCustomerWishProducts", async (req, res) => {
  if (req.body.type == 0) {
    await query(
      "UPDATE wish_list SET quantity=quantity-1 WHERE quantity>0 AND customer_id='" +
        req.body.customerId +
        "' AND item_ids='" +
        req.body.itemId +
        "'"
    );
  } else {
    await query(
      "UPDATE wish_list SET quantity=quantity+1 WHERE customer_id='" +
        req.body.customerId +
        "' AND item_ids='" +
        req.body.itemId +
        "'"
    );
  }
  return res.send({ error: false, message: "Customer wish product updated." });
});

// new api
app.post("/api/deleteCustomerCartProducts", async (req, res) => {
  await query(
    "DELETE FROM temp_sell WHERE customer_id='" +
      req.body.customerId +
      "' AND item_ids='" +
      req.body.itemId +
      "'"
  );
  return res.send({ error: false, message: "Customer cart product deleted." });
});

// new api
app.post("/api/deleteCustomerWishProducts", async (req, res) => {
  await query(
    "DELETE FROM wish_list WHERE customer_id='" +
      req.body.customerId +
      "' AND item_ids='" +
      req.body.itemId +
      "'"
  );
  return res.send({ error: false, message: "Customer wish product deleted." });
});

// new api
app.post("/api/getVendorData", async (req, res) => {
  const vendorData = await query(
    "SELECT name,logo,cover_photo from vendor_details WHERE vendor_id = '" +
      req.body.vendorId +
      "'"
  );
  return res.send({
    error: false,
    data: vendorData[0],
    message: "Vendor Info"
  });
});

// new api
app.post("/api/getVendorCategories", async (req, res) => {
  const VendorCategoryData = await query(
    "SELECT DISTINCT(category_id),category_name from products LEFT JOIN category ON category.id = products.category_id WHERE vendor_id = '" +
      req.body.vendorId +
      "'"
  );
  return res.send({
    error: false,
    data: VendorCategoryData,
    message: "Vendor Info"
  });
});

// new api
app.post("/api/getVendorProductsByCategory", async (req, res) => {
  const ProductData = await query(
    "SELECT id,category_id,product_name,productPrice,home_image,created_date from products WHERE status='active' AND softDelete=0 AND vendor_id = '" +
      req.body.vendorId +
      "' AND category_id IN " +
      "(" +
      req.body.categoryIds +
      ")" +
      ""
  );
  return res.send({ error: false, data: ProductData, message: "CategoryData" });
});

// new api
app.get("/api/getAdvertisement", async (req, res) => {
  const advertData = await query(
    "SELECT image from advertisement WHERE status=1 AND softDel=0"
  );
  return res.send({
    error: false,
    data: advertData[0],
    message: "Advertisement"
  });
});

app.post("/api/getCustomerCartProductsCount", async (req, res) => {
  const customerProductCount = await query(
    "SELECT COUNT(customer_id) as counting from temp_sell WHERE customer_id = '" +
      req.body.customerId +
      "'"
  );
  return res.send({
    error: false,
    data: customerProductCount,
    message: "customer cart product list."
  });
});

app.get("/api/all_category_product_list", async (req, res) => {
  try {
    const productLists = await query(`select category.category_name, products.id, products.product_name, products.home_image, products.category_id, products.productPrice
from category join products on category.id = products.category_id
where products.qc_status='yes' and products.status='active' and products.isApprove=1 and products.softDelete=0;`);
    return res.send({
      error: false,
      data: productLists,
      message: "all category product list."
    });
  } catch (e) {
    console.log("Error occured at the of fetching data from product table");
    console.log(e);

    return res.send({
      error: true,
      data: [],
      message: "Error....."
    });
  }
});

// api created by mehedi
app.get("/api/category_product_list", async (req, res) => {
  try {
    var parentId = req.query.id;

    const productLists = await query(
      "SELECT * FROM products WHERE category_id = " +
        parentId +
        " AND softDelete = 0 AND status = 1"
    );

    return res.send({
      error: false,
      data: productLists,
      message: "all category product list."
    });
  } catch (e) {
    console.log("Error occured at the of fetching data from product table");
    console.log(e);

    return res.send({
      error: true,
      data: [],
      message: "Error....."
    });
  }
});

app.get("/api/get_terms_conditions", async (req, res) => {
  const termsCOnditions = await query("SELECT * FROM terms_conditions");
  // console.log('aaaaa',termsCOnditions[0].terms_and_conditions);
  return res.send({
    error: false,
    data: termsCOnditions[0].terms_and_conditions,
    message: "terms"
  });
});

// new api
app.post("/api/getCustomerInfo", async (req, res) => {
  const customerInfo = await query(
    "SELECT * FROM customer WHERE id='" + req.body.customerId + "'"
  );
  if (customerInfo) {
    const returnData = customerInfo[0];
    return res.send({
      error: false,
      data: returnData,
      message: "Customer Info"
    });
  } else {
    const returnData = [];
    return res.send({
      error: false,
      data: returnData,
      message: "Customer Info"
    });
  }
});

app.post("/api/searchProductList", async (req, res) => {
  var searchKey = req.body.searchKey;
  const productLists = await query(
    "SELECT * FROM products WHERE product_name LIKE '%" +
      searchKey +
      "%' or product_name LIKE '" +
      searchKey +
      "%' or product_name LIKE '%" +
      searchKey +
      "' or product_name='" +
      searchKey +
      "'"
  );
  return res.send({
    error: false,
    data: productLists,
    message: "all search product list."
  });
});

app.get("/api/search_filter_products", (req, res) => {
  dbConnection.query(
    'SELECT * FROM products WHERE vendor_id = "' +
      req.query.vendorId +
      '" AND category_id = "' +
      req.query.categoryList +
      '"',
    function(error, results, fields) {
      if (error) throw error;
      return res.send({ data: results, message: "data" });
    }
  );
});

app.get("/api/search_purchase_products", (req, res) => {
  var searchedProducts = [];

  new Promise(function(resolve, reject) {
    dbConnection.query(
      'SELECT id FROM products WHERE vendor_id = "' +
        req.query.vendorId +
        '" AND product_name LIKE "%' +
        req.query.id +
        '%" OR product_sku LIKE "%' +
        req.query.id +
        '%" ',
      function(error, results, fields) {
        if (error) throw error;
        if (results.length > 0) {
          resolve(results);
        } else {
          reject("rejected");
        }
      }
    );
  })
    .then(function(purchaseElements) {
      // console.log(purchaseElements);

      async.forEachOf(
        purchaseElements,
        function(purchaseElement, i, inner_callback) {
          var select_sql =
            "SELECT products.id AS id, products.home_image as home_image, products.product_name AS product_name, products.product_sku AS product_sku FROM products JOIN inv_purchase_details ON products.id = inv_purchase_details.productId WHERE products.id='" +
            purchaseElement.id +
            "' AND inv_purchase_details.productId='" +
            purchaseElement.id +
            "' ";
          dbConnection.query(select_sql, function(err, results, fields) {
            if (!err) {
              if (results.length > 0) {
                searchedProducts.push(results);
              }

              inner_callback(null);
            } else {
              console.log("Error while performing Query");
              inner_callback(err);
            }
          });
        },
        function(err) {
          if (err) {
            //handle the error if the query throws an error
            console.log("Error at ASYNC");
            return res.send({ data: [], message: "data" });
          } else {
            //whatever you wanna do after all the iterations are done
            console.log("Success at ASYNC");
            return res.send({ data: searchedProducts, message: "data" });
          }
        }
      );
    })
    .catch(function(reject) {
      console.log("Rejected");
      return res.send({ data: [], message: "data" });
    });

  // return res.send({ success: 'true', data: req.query.id, message: 'data' });
});

app.get("/api/product_list", (req, res) => {
  dbConnection.query(
    `SELECT * FROM products WHERE softDelete = 0 AND isApprove='authorize' AND status = 'active' limit 5`,
    function(error, results, fields) {
      console.log(results);
      if (error) throw error;
      return res.send({
        error: error,
        data: results,
        message: "sepecification name list."
      });
    }
  );
});

app.post("/api/saveCategory", (req, res) => {
  //return res.send({success:true});
  return res.send(req.body);
  //console.log(req);
});

app.listen(3001, () =>
  console.log("Express server is running on localhost:3001")
);
