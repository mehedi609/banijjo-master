/**
 * package   SP Vertical Mega Menu
 *
 * @version 1.0.0
 * @author    MagenTech http://www.magentech.com
 * @copyright (c) 2014 YouTech Company. All Rights Reserved.
 * @license   http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */
import $ from "jquery";

(function($, window, document, undefined) {
  $.fn.doubleTapToGo = function(params) {
    if (
      !("ontouchstart" in window) &&
      !navigator.msMaxTouchPoints &&
      !navigator.userAgent.toLowerCase().match(/windows phone os 7/i)
    )
      return false;

    this.each(function() {
      var curItem = false;

      $(this).on("click", function(e) {
        var item = $(this);
        if (item[0] != curItem[0]) {
          e.preventDefault();
          curItem = item;
        }
      });

      $(document).on("click", function(e) {
        var resetItem = true,
          parents = $(e.target).parents();
        for (var i = 0; i < parents.length; i++)
          if (parents[i] == curItem[0]) resetItem = false;

        if (resetItem) curItem = false;
      });
    });
    return this;
  };
})($, window, document);
