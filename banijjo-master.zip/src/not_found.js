 import React from 'react';

const notFound = ()=>{
    return <div>404 Not Found</div>
}

export default notFound;